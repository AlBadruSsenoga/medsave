<footer class="main-footer">
    <div class="footer-content">
        <p>&copy; <?php echo date('Y'); ?> Maternal AI Triage System</p>
        <p>Medsave Team - Industry 4.0+ Hackthon.  For support, WhatsApp +256700760705</p>
    </div>
</footer>
